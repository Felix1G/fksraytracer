use anyhow::anyhow;

fn main() {
    let _ = anyhow!(&String::new());
}
