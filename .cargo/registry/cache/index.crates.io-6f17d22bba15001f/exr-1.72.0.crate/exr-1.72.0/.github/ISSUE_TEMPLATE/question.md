---
name: Question
about: Something's unclear or undocumented
title: ''
labels: question
assignees: ''

---

I wanted to do X.
I expected to find it in the documentation for Y or example Z.
