# image-webp

WebP encoding and decoding in pure Rust
